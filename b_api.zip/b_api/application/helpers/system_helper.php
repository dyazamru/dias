<?php  if (!defined('BASEPATH')) exit('No direct script access allowed'); 
function load_view($data, $CIobj = '', $ret_view = false ){
	//get curr theme
	global $use_theme, $base_template;
	if(empty($CIobj)){
		$CIobj =& get_instance();
	}
	
	if(!empty($data['use_theme'])){
		$use_theme = $data['use_theme'];
	}
	else{
		$use_theme = TEMPLATE;
	}
	
	$file_theme = 'index';
	if(!empty($data['file_theme'])){
		$file_theme = $data['file_theme'];
	}
	else{
		$file_theme = FILE_TEMP;
	}
	
	if(empty($data['dir'])){
		$data['dir'] = DIR;
	}
	
	$main_content = 'index';
	if(!empty($data['main_content'])){
		$main_content = $data['main_content'];
	}
	
	//check theme file
	if (@file_exists(THEME_PATH .$use_theme.'/'.$file_theme.'.php')) {
		if(!defined('CSS_THEME_URL')){
			define('CSS_THEME_URL', THEME_URL .$use_theme.'/css/');		
		}
		if(!defined('IMAGE_THEME_URL')){
			define('IMAGE_THEME_URL', THEME_URL .$use_theme.'/images/');
			//$CIobj->js->inline('var IMAGE_THEME_URL = \''.IMAGE_THEME_URL.'\';'."\n");	
		}
		if(!defined('JS_THEME_URL')){
			define('JS_THEME_URL', THEME_URL .$use_theme.'/js/');					
		}
		if(!defined('CURR_THEME_URL')){
			define('CURR_THEME_URL', THEME_URL . $use_theme.'/');
			//$CIobj->js->inline('var CURR_THEME_URL = \''.CURR_THEME_URL.'\';'."\n");			
		}
		if(!defined('CURR_THEME_PATH')){
			define('CURR_THEME_PATH', THEME_PATH . $use_theme.'/');
		}
		if(!defined('CURR_MOD_URL')){
			define('CURR_MOD_URL', APP_URL.MOD_DIR.'/'.module_var().'/');				
			/* $CIobj->js->inline('var BASE_URL = \''.BASE_URL.'\';'."\n");
			$CIobj->js->inline('var MODULE_URL = \''.module_url().'\';'."\n");		
			$CIobj->js->inline('var BASE_MODULE_URL = \''.CURR_MOD_URL.'\';'."\n");
			$CIobj->js->inline('var CURR_MODULE = \''.module_var().'\';'."\n"); */
		}
		
		if($ret_view){
			$data_view = $CIobj->load->view($use_theme .'/'.$file_theme, $data, true);
		}else{
			$data_view = $CIobj->load->view($use_theme .'/'.$file_theme, $data);
		}
		return $data_view;
	}else{
		echo 'LOAD THEME : '.$use_theme.' FAILED! <br/>check here : '.THEME_PATH .$use_theme.'/'.$file_theme.'.php'; die();
	}
	
}

function clear_html($v){
	return htmlspecialchars($v,ENT_QUOTES);
}

function module_var($segment = 1, $CIobj = '', $echoed = false){
	if(empty($CIobj)){
		$CIobj =& get_instance();
	}
	$segs = $CIobj->uri->segment_array();
	if(!empty($segs[$segment])){
		$curr_module_var = $segs[$segment];
	}else{
		$curr_module_var = '';
	}
	
	$curr_module_var = strtolower($curr_module_var);
	
	if($echoed){
		echo $curr_module_var;
	}else{		
		return $curr_module_var;
	}
}

function write_log($action,$user='',$last_log_id='',$user_agent=''){
	$CIobj =& get_instance();
	$CIobj->db->query("alter session set nls_date_format='yyyy-mm-dd hh24:mi:ss'");
	$action = str_replace(",",", ",$action);
	if (!empty($_SERVER['HTTP_CLIENT_IP'])){
		$ip=$_SERVER['HTTP_CLIENT_IP'];
	}
	elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
		$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
	}
	else{
		$ip=$_SERVER['REMOTE_ADDR'];
	}
	
  
    $user_sess = $CIobj->session->userdata("username");
	if(!empty($user_sess)){
		$username = $CIobj->session->userdata("username");
	}
	else{
		$username = $user;
	}
	 $db2 = $CIobj->load->database('tria', TRUE);
	if(!empty($username)){
		//$db2->trans_start();
			$db2->set("LAST_ACTIVITY","SYSDATE",false);
			$db2->where("USERNAME",$username);
			$db2->update("UI_USERS");
		//$db2->trans_complete();
	}
	//last_log_id
	//$db2->select("*")->from("UI_LOGACTIVITY")->where("USERNAME",$username);
    $action = str_replace("'","''",htmlspecialchars($action,ENT_QUOTES));
	$last_timestamp = get_name("UI_LOGACTIVITY","TO_CHAR(TIMESTAMP_DATE,'yyyy-mm-dd hh24:mi:ss')","LOGID",$last_log_id);
	$seconds = 0;
	if(!empty($last_timestamp)){
		$timeFirst = strtotime($last_timestamp);
		$now = strtotime(date('Y-m-d H:i:s'));
		$seconds = (int)$now - (int)$timeFirst;
	}
	
	$data_log = array("DURATION"=>$seconds);
	$db2->where("LOGID",$last_log_id);
	$db2->update('UI_LOGACTIVITY',$data_log);
	
	$log_id = get_next_id("UI_LOGACTIVITY");
	
	$data_log = array("LOGID"=>$log_id,
					   "USERNAME"=>$username,
					   "ACTION"=>$action,
					   "NOTE"=>$user_agent,
					   "DURATION"=>$seconds,
					   "IP"=>$ip);
	$db2->set("TIMESTAMP_DATE","SYSDATE",false);
	$db2->insert('UI_LOGACTIVITY',$data_log);
	
	return $log_id;
}

function get_next_id($table_name){
    $ci =& get_instance();
	$db2 = $ci->load->database('tria', TRUE);
	$query = 'select '.$table_name.'_SEQ.NEXTVAL from dual';

	$stid = oci_parse($db2->conn_id, $query);
	$r = oci_execute($stid, OCI_DEFAULT);

	while ($row = oci_fetch_row($stid)) {
	  foreach($row as $item) {
		  $next_id = $item;
	  }
	}
    return $next_id;
}


function get_name($table,$field,$find,$value,$add_where=""){
   $CIobj =& get_instance();
   if(!empty($value)){
	   $db2 = $CIobj->load->database('tria', TRUE);
	   $q = $db2->query("select ".$field." as RESULT from ".$table." where ".$find."='".$value."' ".$add_where);
	   $rows = $q->result_array();
	   
	   if(@$rows[0]){
			return @$rows[0]['RESULT'];
	   }
	   else{
		   //write_log( "parse error/empty result for : select ".$field." as result from ".$table." where ".$find."=".$value." ".$add_where);
	   }
   }
   else{
	   return 0;
   }
}

function has_privilege($username,$module_name,$priv="_view"){
    if(empty($username) or empty($module_name)){
      redirect('login');
      return false;
    }
		$CIobj =& get_instance();
		
		$priv = strtoupper("HAS".$priv);
		
		//$CIobj->db->query("alter session set nls_date_format='yyyy-mm-dd hh24:mi:ss'");
		$module_id = get_name("UI_MODULES","MODULE_ID","MODULE_VAR",$module_name);
		//write_log("Accessing module ".$module_name." (".$priv.")");
		$userid = $CIobj->session->userdata('userid');
		
		$CIobj->db->select("IS_LOGIN,LOGIN_TOKEN,LAST_ACTIVITY,IS_BLOCK")->from("UI_USERS")->where("USER_ID",$userid);
		$qc = $CIobj->db->get();
		//echo $CIobj->db->last_query();
		$dc = $qc->result_array();
		
		$last_activity = @$dc[0]['LAST_ACTIVITY'];
		//echo $last_activity;
		$is_block = @$dc[0]['IS_BLOCK'];
		$now = date("Y-m-d H:i:s");
		$seconds = strtotime($now) - strtotime($last_activity);
		$minute = floor($seconds/60);
		$idle_time = getPref('_SESSION_IDLE_TIME');
		//echo "idle for : ".$minute;
		if($minute>=$idle_time){
			$CIobj->db->trans_start();
			//echo "masuk idle time ".$minute." ".$idle_time;
			$CIobj->db->query("update UI_USERS set IS_LOGIN = 'N' where USER_ID='".$userid."'");
			$CIobj->db->trans_complete();
			write_log("user session has been expired ");
			$CIobj->session->sess_destroy();
			$data['error_msg'] = "Your session has been expired";
		
		    echo "Your session has been expired, click <a href='".base_url()."login'>here</a> to relogin <br /> ";
			return false;
		}
		
        
		if($is_block=="Y"){
			//echo "masuk block";
			//$CIobj->db->query("update UI_USERS set IS_LOGIN = 'N' where USER_ID='".$userid."'");
			write_log("user session has been terminated");
			$CIobj->session->sess_destroy();
			$data['error_msg'] = "Your account has been blocked";
			//redirect('login');
			//$CIobj->load->view("login/login_temp",$data);
			return false;
			exit;
		}
		
		$groupid = $CIobj->session->userdata('groupid');
		$userid = $CIobj->session->userdata('userid');
		$token = $CIobj->session->userdata('login_token');
		
		if(empty($userid)){
			//echo "masuk session gak ke save";
			$data['error_msg'] = "Your session has been expired";
			return false;
			exit;
		}
		
		
		//check login 
		
		//print_r($dc);
		if(@$dc[0]["IS_LOGIN"]=="N" or $token!=@$dc[0]["LOGIN_TOKEN"]){
			//destroy session
			echo "masuk login token sama is login = n";
			$CIobj->session->sess_destroy();
			$data['error_msg'] = "Your session has been expired";
			$CIobj->load->view("login/login_temp",$data);
			return false;
			exit;
		}
		else{
			
			$CIobj->db->select("*")->from("UI_PRIVILEGE")->where("GROUP_ID",$groupid)->where("MODULE_ID",$module_id)->where($priv,1);
			$q =  $CIobj->db->get();
			//echo "select * from UI_PRIVILEGE where GROUP_ID = '".$groupid."' and MODULE_ID = '".$module_id."' and ".$priv."=1";
			$num = $q->num_rows();
			
			if(!empty($num)){
				//update last activity
				//echo $priv;
				if($priv=="is_view"){
					//echo "test";
					$access_module = get_name("UI_MODULES","MODULE_NAME","MODULE_VAR",$module_name);
					write_log("Access ".$access_module);
				}
				$CIobj->db->trans_start();
				$CIobj->db->query("update UI_USERS set LAST_ACTIVITY = '".date("Y-m-d H:i:s")."', LAST_MODULE='".$module_name."', IS_LOGIN='Y' where USER_ID = '".$userid."'");
				$CIobj->db->trans_complete();
				return true;
			}
			else{
				//echo "You don't have permission to access this feature";
				return false;
			}
		}
}
function getOptionList($table,$selected_id,$id_name,$list_name,$where="",$all=true){
	$ci =& get_instance();
	$ci->db->select("*")->from($table,false);
	//echo $where;
	if($where){
		$ci->db->where($where);
	}
	$q = $ci->db->get();
	//echo $ci->db->last_query();
	$d = $q->result_array();
	$html = "";
	if($all){
		$html = "<option value='0'>- All ".str_replace("REF","",str_replace("_"," ",$table))."-</option>";
	}
	$selected = "";
	//echo $id_name;
	foreach($d as $k=>$v){
		if($d[$k][$id_name]==$selected_id){
			$selected = "selected = 'selected'";
		}
		$html.="<option value='".$d[$k][$id_name]."' ".$selected.">".$d[$k][$list_name]."</option>";
		$selected ="";
	}
	return $html;
}

function array_sort($array, $on, $order=SORT_ASC){

    $new_array = array();
    $sortable_array = array();

    if (count($array) > 0) {
        foreach ($array as $k => $v) {
            if (is_array($v)) {
                foreach ($v as $k2 => $v2) {
                    if ($k2 == $on) {
                        $sortable_array[$k] = $v2;
                    }
                }
            } else {
                $sortable_array[$k] = $v;
            }
        }

        switch ($order) {
            case SORT_ASC:
                asort($sortable_array);
                break;
            case SORT_DESC:
                arsort($sortable_array);
                break;
        }

        foreach ($sortable_array as $k => $v) {
            $new_array[$k] = $array[$k];
        }
    }

    return $new_array;
}

function getColor($label){
	$label = trim($label);
	$color_set = file_get_contents("color_set.data");
	$color_tmp = json_decode($color_set,true);
	$color_arr = array();
	foreach($color_tmp as $k=>$v){
		foreach($v as $kk=>$vv){
			$color_arr[$kk]=$vv;
		}
	}
	
	//print_r($color_arr);
	if($label=="Cost of Card/Distribution"){
		return '#ababab';
	}
	if(isset($color_arr[$label])){
		return $color_arr[$label];
	}
	else{
		return '#cccccc';
	}
}

function getIcon($label){
	$icon = array("Voice"=>"fa fa-phone",
				  "All"=>"fa fa-th-large",
				  "VOICE"=>"fa fa-phone",
				  "Broadband"=>"fa fa-rss",
				  "Dig Service"=>"fa fa-signal",
				  "SMS"=>"fa fa-envelope-o");
	$label = trim($label);
	if(@$icon[$label]){
		return $icon[$label];
	}else{
		return 0;
	}
}

function getSysTxt($symbol){
	$data=array("TLKM.JK"=>"PT Telekomunikasi Indonesia Tbk",
				"EXCL.JK"=>"PT XL Axiata Tbk",
				"ISAT.JK"=>"PT Indosat Tbk",
				"^JKSE"=>"Jakarta Composite Index");
	return $data[$symbol];
}

function getIndex($label){
	$label = trim($label);
	//Dig. Lifestyle, Dig. Advertising and Analytics, Dig. Enterprise Solution, Big Data and API Business, Mobile Financial Services, CP Share
	$index = array("Operations & Maintenance Expenses"=>1,
				 "Marketing & Sales Expenses"=>2,
				 "Personnel Expenses"=>3,
				 "General And Administrative Expenses"=>4,
				 "Voice PAYU"=>1,
				 "SMS PAYU"=>1,
				 "Voice Package"=>2,
				 "SMS Package"=>2,
				 "Cost Of Services"=>5,
				 "Cost Of Products"=>1,
				 "Cost Of Collection"=>2,
				 "Interconnection Charges"=>6,
				 "Digital Services"=>4,
				   "Broadband"=>3,
				   "OTHERS"=>5,
				   "SAD REGIONAL"=>6,
				   "AREA 1"=>1,
				   "AREA 2"=>2,
				   "AREA 3"=>3,
				   "AREA 4"=>4,
				   "HO"=>5,
				   "FINARYA"=>6,
				   "SUMBAGUT"=>1,	
				   "SUMBAGTENG"=>2,	
				   "SUMBAGSEL"=>3,
				   "JABOTABEK"=>1,
				   "WESTERN JABOTABEK"=>4,
				   "CENTRAL JABOTABEK"=>5,
				   "EASTERN JABOTABEK"=>6,
				   "JABAR"=>7,
				   "JATENG"=>8,
				   "JATENG-DIY"=>1,
				   "JATIM"=>9,
				   "BALINUSRA"=>10,
				   "BALI NUSRA"=>10,
				   "KALIMANTAN"=>11,
				   "SULAWESI"=>12,
				   "PUMA"=>13,
				   "MALUKU DAN PAPUA"=>3,
				   "Flash"=>1,
				   "PAYU"=>2,
				   "Blackberry"=>3,
				   "All"=>0,
				   "Voice"=>1,
				   "SMS"=>2,
				   "Data"=>3,
				   "Dig. Service"=>11,
				   "Dig Service"=>11,
				   "Digital"=>4,
				   "Interconection"=>7,
				   "ARPU < 50k"=>1,
				   "ARPU 50-70k"=>2,
				   "ARPU > 70k"=>3,
				   "CP Share"=>6,
				   "Mobile Financial Services"=>5,
				   "Big Data and API Business"=>4,
				   "Dig. Enterprise Solution"=>3,
				   "Dig. Advertising and Analytics"=>2,
				   "Dig. Lifestyle"=>1,
				   "Others Cost"=>7,
				   "Customer Relationship Management"=>6,
				   "Bad Debt"=>5,
				   "Cost of Collection"=>4,
				   "Cost of Product"=>3,
				   "Concession Fee and Other Charges"=>4,
				   "Access Fee"=>3,
				   "Administrative Expenses"=>2,
				   "General Expenses"=>1,
				   "Employee Benefit"=>2,
				   "Salaries & Allowances"=>1,
				   "Others Marketing Expenses"=>5,
				   "Customer Loyalty Programs"=>4,
				   "Customer Communications"=>3,
				   "Advertising"=>2,
				   "KARTUHALO"=>1,
				   "SIMPATI"=>2,
				   "KARTU AS"=>3,
				   "KARTUAS"=>3,
				   "LOOP"=>4,
				   "HYBRID"=>5,
				   "UNKNOWN"=>6,
				   "Sales Support"=>1,
				   "Freq / BTS"=>8,
				   "Freq / Site"=>7,
				   "Power /BTS"=>6,
				   "Power /Site"=>5,
				   "NSR/ BTS"=>4,
				   "NSR/ Site"=>3,
				   "O & M / BTS"=>2,
				   "O & M / Site"=>1,
				   "Network Administration Expenses"=>6,
				   "Repair and Maintenance Charges"=>5,
				   "Tower and Space Rental"=>4,
				   "Power Expenses"=>3,
				   "Transmission Charges"=>2,
				   "Radio Frequency Usage Fee"=>1,
				   "International Roaming"=>5,
				   "Nw. Leased"=>8,
				   "Discount"=>99,
				   "Others"=>7,
				   "SMS P2P"=>2,
				   "Sales Discount"=>4,
				   "USO"=>9,
				   "IR"=>5,
				   "IC"=>6,
				   "Smart Attacker"=>4,
				   "Transit via Telkom"=>1,
				   "Direct"=>2,
				   "SLI"=>3,
				   "Synergi"=>4,
				   "Network Leased"=>7,
				   "LOS < 3 mnth ARPU < 50k"=>1,
				   "LOS < 3 mnth ARPU 50-70k"=>2,
				   "LOS < 3 mnth ARPU > 70k"=>3,
				   "LOS 3-12 mnth ARPU < 50k"=>4,
				   "LOS 3-12 mnth ARPU 50-70k"=>5,
				   "LOS 3-12 mnth ARPU > 70k"=>6,
				   "LOS > 12 mnth ARPU < 50k"=>7,
				   "LOS > 12 mnth ARPU 50-70k"=>8,
				   "LOS > 12 mnth ARPU > 70k"=>9,
				   "B2B"=>3,
				   "Postpaid"=>2,
				   "Prepaid"=>1,
				   "Voice P2P"=>1,
				   "General Administration"=>4,
				   "Marketing"=>2,
				   "Personnel"=>3,
				   "Operation & Maintenance"=>1,
				   "Others Expense"=>5,
				   "2G"=>1,
				   "3G"=>2,
				   "4G"=>3,
				   "5G"=>4,
				   "6G"=>5,
				   "SMS Trx Bonus"=>1,
				   "SMS Trx Regular"=>2,
				   "SMS Trx Package"=>3,
				   "MoU Bonus"=>1,
				   "MoU Package"=>2,
				   "MoU Regular"=>3,/*from here*/
				   "HVC"=>1,
				   "Non HVC"=>2,
				   "NON HVC"=>2,
				   "CONSUMER"=>3,
				   "LE"=>1,
				   "SME"=>2,
				   "Corporate"=>3,
				   "CORPORATE"=>3,
				   "Government"=>4,
				   "GOVERNMENT"=>4,
				   "ENTERPRISE"=>5,
				   "TMI"=>1,
				   "LinkAja"=>2,
				   "IoT"=>1,
				   "Big Data & API"=>2,
				   "Digi Ads & Banking"=>3,
				   "B2C"=>1,
				   //"B2B"=>2,
				   "Subsidiary"=>4,
				   "Incubation"=>5,
				   "Wholesale"=>6,
				   "WHOLESALE"=>6,
				   "Infrastructure Leased"=>1,
				   "Interconnection"=>2,
				   "WHOLESALE"=>6,
				   "Revenue"=>1,
				   "COE TSEL"=>2,
				   "COE Telkom"=>3,
				   "EBITDA Before"=>4,
				   "EBITDA Before Margin"=>5,
				   "EBITDA After"=>6,
				   "EBITDA After Margin"=>7,
				   "DEPRE TSEL"=>8,
				   "DEPRE Telkom"=>9,
				   "EBIT Before"=>10,
				   "EBIT Before Margin"=>11,
				   "EBIT After"=>12,
				   "EBIT After Margin"=>13,
				   "Others & CIT"=>14,
				   "NI Before"=>15,
				   "NI Before Margin"=>16,
				   "NI After"=>17,
				   "NI After Margin"=>18,
				   "Indirect" =>3,
				   "TLKM.JK"=>1,
				   "ISAT.JK"=>2,
				   "^JKSE"=>4,
				   "EXCL.JK"=>3,
				   "CONSENSUS"=>1,
				   "TELKOMSEL"=>2,
				   "INDOSAT"=>11,
				   "XL"=>12,
				   "SMARTFREN"=>13,
				   "HUTCH"=>14,
				   "ACTUAL"=>1,
				   "OUTLOOK"=>1,
				   "Bahana"=>2,
				   "CIMB"=>3,
				   "DB"=>4,
				   "HSBC"=>5,
				   "Mandiri Sekuritas"=>6,
				   "UBS"=>7,
				   "Deutsche Bank"=>8,
				   "Cost of Customer Call Handling / Subs"=>1,
				   "Cost of Card / Sales"=>2,
				   "Depreciation Of Leased Assets"=>1,
				   "Depreciation Of Direct Ownership Of Fixed Assets"=>2,
				   "Amortization"=>3,
				   "Finance Income and Charges"=>1,
				   "Other Income / (Expenses)"=>2,
				   "Gain / (Loss) On Assets"=>3,
				   "Foreign Exchange"=>4,
				   "CENTRAL JABOTABEK"=>5,
				   "EASTERN JABOTABEK"=>6,
				   "BULK"=>1,
				   "FIX"=>2,
				   "ERROR"=>3,
				   "NQ"=>600,
				   "TOTAL"=>1000
				   );
	$label = trim($label);
	if(@$index[$label]){
		return $index[$label];
	}else{
		if(@$index[$label]===0){
			return @$index[$label];
		}
		else{
			return 500;
		}
	}
}

function getIndex2($label){
	//Dig. Lifestyle, Dig. Advertising and Analytics, Dig. Enterprise Solution, Big Data and API Business, Mobile Financial Services, CP Share
	$index = array("Operations & Maintenance Expenses"=>1,
				 "Marketing & Sales Expenses"=>2,
				 "Personnel Expenses"=>3,
				 "General And Administrative Expenses"=>4,
				 "Voice PAYU"=>1,
				 "SMS PAYU"=>1,
				 "Voice Package"=>2,
				 "SMS Package"=>2,
				 "Cost Of Services"=>5,
				 "Cost Of Products"=>1,
				 "Cost Of Collection"=>2,
				 "Interconnection Charges"=>6,
				 "Digital Services"=>10,
				   "Broadband"=>10,
				   "OTHERS"=>7,
				   "SAD REGIONAL"=>6,
				   "AREA 1"=>1,
				   "AREA 2"=>2,
				   "AREA 3"=>3,
				   "AREA 4"=>4,
				   "SUMBAGUT"=>1,	
				   "SUMBAGTENG"=>2,	
				   "SUMBAGSEL"=>3,
				   "JABOTABEK"=>1,
				   "JABAR"=>2,
				   "JATENG"=>1,
				   "JATENG-DIY"=>1,
				   "JATIM"=>2,
				   "BALINUSRA"=>3,
				   "BALI NUSRA"=>3,
				   "KALIMANTAN"=>1,
				   "SULAWESI"=>2,
				   "PUMA"=>3,
				   "MALUKU DAN PAPUA"=>3,
				   "Flash"=>1,
				   "PAYU"=>2,
				   "Blackberry"=>3,
				   "Voice"=>1,
				   "SMS"=>2,
				   "Data"=>3,
				   "Dig. Service"=>11,  
				   "Digital"=>4,
				   "Interconection"=>6,
				   "ARPU < 50k"=>1,
				   "ARPU 50-70k"=>2,
				   "ARPU > 70k"=>3,
				   "CP Share"=>6,
				   "Mobile Financial Services"=>5,
				   "Big Data and API Business"=>4,
				   "Dig. Enterprise Solution"=>3,
				   "Dig. Advertising and Analytics"=>2,
				   "Dig. Lifestyle"=>1,
				   "Others Cost"=>7,
				   "Customer Relationship Management"=>6,
				   "Bad Debt"=>5,
				   "Cost of Collection"=>4,
				   "Cost of Product"=>3,
				   "Concession Fee and Other Charges"=>4,
				   "Access Fee"=>3,
				   "Administrative Expenses"=>2,
				   "General Expenses"=>1,
				   "Employee Benefit"=>2,
				   "Salaries & Allowances"=>1,
				   "Others Marketing Expenses"=>5,
				   "Customer Loyalty Programs"=>4,
				   "Customer Communications"=>3,
				   "Advertising"=>2,
				   "KARTUHALO"=>1,
				   "SIMPATI"=>2,
				   "KARTU AS"=>3,
				   "LOOP"=>4,
				   "HYBRID"=>5,
				   "UNKNOWN"=>6,
				   "Sales Support"=>1,
				   "Freq / BTS"=>8,
				   "Freq / Site"=>7,
				   "Power /BTS"=>6,
				   "Power /Site"=>5,
				   "NSR/ BTS"=>4,
				   "NSR/ Site"=>3,
				   "O & M / BTS"=>2,
				   "O & M / Site"=>1,
				   "Network Administration Expenses"=>6,
				   "Repair and Maintenance Charges"=>5,
				   "Tower and Space Rental"=>4,
				   "Power Expenses"=>3,
				   "Transmission Charges"=>2,
				   "Radio Frequency Usage Fee"=>1,
				   "International Roaming"=>6,
				   "Nw. Leased"=>7,
				   "Discount"=>99,
				   "Others"=>5,
				   "SMS P2P"=>2,
				   "Sales Discount"=>4,
				   "USO"=>8,
				   "IR"=>4,
				   "IC"=>5,
				   "Transit via Telkom"=>1,
				   "Direct"=>2,
				   "SLI"=>3,
				   "Synergi"=>4,
				   "Network Leased"=>6,
				   "LOS < 3 mnth ARPU < 50k"=>1,
				   "LOS < 3 mnth ARPU 50-70k"=>2,
				   "LOS < 3 mnth ARPU > 70k"=>3,
				   "LOS 3-12 mnth ARPU < 50k"=>4,
				   "LOS 3-12 mnth ARPU 50-70k"=>5,
				   "LOS 3-12 mnth ARPU > 70k"=>6,
				   "LOS > 12 mnth ARPU < 50k"=>7,
				   "LOS > 12 mnth ARPU 50-70k"=>8,
				   "LOS > 12 mnth ARPU > 70k"=>9,
				   "B2B"=>3,
				   "Postpaid"=>2,
				   "Prepaid"=>1,
				   "Voice P2P"=>1,
				   "General Administration"=>4,
				   "Marketing"=>2,
				   "Personnel"=>3,
				   "Operation & Maintenance"=>1,
				   "Others Expense"=>5,
				   "2G"=>1,
				   "3G"=>2,
				   "4G"=>3,
				   "5G"=>4,
				   "6G"=>5,
				   "SMS Trx Bonus"=>1,
				   "SMS Trx Regular"=>2,
				   "SMS Trx Package"=>3,
				   "MoU Bonus"=>1,
				   "MoU Package"=>2,
				   "MoU Regular"=>3,
				   "HVC"=>1,
				   "Non HVC"=>2,
				   "LE"=>1,
				   "SME"=>2,
				   "Corporate"=>3,
				   "Government"=>4,
				   "TMI"=>1,
				   "LinkAja"=>2,
				   "IoT"=>1,
				   "Big Data & API"=>2,
				   "Digi Ads & Banking"=>3,
				   "B2C"=>1,
				   //"B2B"=>2,
				   "Subsidiary"=>3,
				   "Incubation"=>4,
				   "Wholesale"=>5
				   );
	$label = trim($label);
	if(@$index[$label]){
		return $index[$label];
	}else{
		return 0;
	}
}

function getLabel($date,$period="PTD",$show_type=""){
	if($period=="QTD" or $period=="QoQ"){
		$date = str_replace("Jan ","Q1-",$date);
		$date = str_replace("Feb ","Q1-",$date);
		$date = str_replace("Mar ","Q1-",$date);
		$date = str_replace("Apr ","Q2-",$date);
		$date = str_replace("May ","Q2-",$date);
		$date = str_replace("Jun ","Q2-",$date);
		$date = str_replace("Jul ","Q3-",$date);
		$date = str_replace("Aug ","Q3-",$date);
		$date = str_replace("Sep ","Q3-",$date);
		$date = str_replace("Oct ","Q4-",$date);
		$date = str_replace("Nov ","Q4-",$date);
		$date = str_replace("Dec ","Q4-",$date);
		return $date;
	}
	else{
		if($show_type=="weekly"){
			$date = str_replace("01","w1",$date);
			$date = str_replace("08","w2",$date);
			$date = str_replace("15","w3",$date);
			$date = str_replace("22","w4",$date);
			return $date;
		}
		else{
			return $date;
		}
	}
}

function getLastUpdate($qdata,$year,$label="Revenue Outlook"){
	$ci =& get_instance();
	
	$qdata = trim($qdata);
	if(!empty($qdata)){
		$qarr = array("Q1"=>"03",
					  "Q2"=>"06",
					  "Q3"=>"09",
					  "Q4"=>"12");
					  
		$month = $qarr[$qdata];
		$ci->db->select("PERIOD")->from("TR_LAST_UPDATE_DATA")->where("REPORT",$label)->where("SUBSTR(PERIOD,0,6)",$year.$month);
		$q = $ci->db->get();
		
		//echo $ci->db->last_query();
		$n = $q->num_rows();
		if(!empty($n)){
			$d = $q->result_array();
			$ret =  date("d",strtotime($d[0]["PERIOD"]));
		}
		else{
			$ret = date("t",strtotime($year."-".$month."-01"));
		}
	}
	else{
		$ret = date("t");
	}
	return $ret;
}

function getLastUpdate2($qdata,$year,$label="Revenue Outlook"){
	$ci =& get_instance();
	//echo $qdata." ".$year." ".$label;
	if(!empty($qdata)){
		$qarr = array("Q1"=>"03",
					  "Q2"=>"06",
					  "Q3"=>"09",
					  "Q4"=>"12");
					  
		$month = $qarr[$qdata];
		$ci->db->select("PERIOD")->from("TR_LAST_UPDATE_DATA")->where("REPORT",$label)->where("SUBSTR(PERIOD,0,6)",$year.$month);
		$q = $ci->db->get();
		
		//echo $ci->db->last_query();
		$n = $q->num_rows();
		if(!empty($n)){
			$d = $q->result_array();
			$ret =  date("d",strtotime($d[0]["PERIOD"]));
		}
		else{
			$ret = "last";
		}
	}
	else{
		$ret = "last";
	}
	return $ret;
}

function LastUpdate(){
	$ci =& get_instance();
	$ci->db->select("PERIOD")->from("TR_LAST_UPDATE_DATA")->order_by("PERIOD DESC")->limit(2)->where("REPORT","Revenue Outlook");
	$q = $ci->db->get();
	//echo $ci->db->last_query();
	$d = $q->result_array();
	return @$d[0]["PERIOD"];
}

function LastUpdateTableau($report_name="Revenue Outlook"){
	$ci =& get_instance();
	$ci->db->select("PERIOD,FLAG")->from("TR_LAST_UPDATE_DATA")->order_by("PERIOD DESC")->limit(2)->where("REPORT",$report_name);
	$q = $ci->db->get();
	$d = $q->result_array(); //@$d[0]["PERIOD"]
	return $d;
}


function getUpdateDate($selected_date='',$report='Usage'){
	$today = (int)date("Ymd");
	$date = (int)$selected_date;
	if($date<$today){
		$ci =& get_instance();
		$ci->db->select("PERIOD")->from("TR_LAST_UPDATE_DATA")->where("REPORT",$report);
		$q = $ci->db->get();
		$d = $q->result_array();
		$last_update = (int)$d[0]["PERIOD"];
		
		if($date<$last_update){
			$date = $selected_date;
		}
		else{
			$date = $last_update;
		}
	}
	else{
		$date = $selected_date;
	}
	
	return $date;
}

function getQdateList($qdata,$year,$label="Revenue Outlook",$margin = 12){
	$qdate = getLastUpdate2($qdata,$year,$label);
	//$qdate = 29;
	$date_list = array();
	if(!empty($qdata)){
		if($qdate=="last"){
			$default_margin = $margin;
			$date_list = array();
			$qarr = array("Q1"=>date("Ymd",strtotime($year."-03-01")),
						  "Q2"=>date("Ymd",strtotime($year."-06-01")),
						  "Q3"=>date("Ymd",strtotime($year."-09-01")),
						  "Q4"=>date("Ymd",strtotime($year."-12-01")));
			$date_select = $qarr[$qdata];
			$date_list[] = date("Ymd",strtotime($date_select));
			$first = true;
			 for($i=0;$i<$default_margin;$i++){
				$min = 3;
				$cur_date = date("Ymd",strtotime("last day of ".$date_select." -".$min." month"));
				$date_list[] = $cur_date;
				$date_select = $cur_date;
				$first = false;
			}
		}
		else{
			$default_margin = $margin;
			$date_list = array();
			$qarr = array("Q1"=>date("Ymd",strtotime($year."-03-".$qdate)),
						  "Q2"=>date("Ymd",strtotime($year."-06-".$qdate)),
						  "Q3"=>date("Ymd",strtotime($year."-09-".$qdate)),
						  "Q4"=>date("Ymd",strtotime($year."-12-".$qdate)));
			$date_select = $qarr[$qdata];
			$date_list[] = date("Ymd",strtotime($date_select));
			$first = true;
			 for($i=0;$i<$default_margin;$i++){
				$min = 3;
				$cur_date = date("Ymd",strtotime($date_select." -".$min." month"));
				$date_list[] = $cur_date;
				$date_select = $cur_date;
				$first = false;
			}
		}
	}
	
	return $date_list;
}

function getQdateList2($qdata,$year,$label="Revenue Outlook",$margin = 12){
	$qdate = getLastUpdate2($qdata,$year,$label);
	//$qdate = 29;
	$date_list = array();
	if(!empty($qdata)){
		if($qdate=="last"){
			$default_margin = $margin;
			$date_list = array();
			$qarr = array("Q1"=>date("Ymd",strtotime($year."-03-01")),
						  "Q2"=>date("Ymd",strtotime($year."-06-01")),
						  "Q3"=>date("Ymd",strtotime($year."-09-01")),
						  "Q4"=>date("Ymd",strtotime($year."-12-01")));
			$date_select = $qarr[$qdata];
			$date_list[] = date("Ymd",strtotime($date_select));
			$first = true;
			 for($i=0;$i<$default_margin;$i++){
				$min = 12;
				$cur_date = date("Ymd",strtotime("last day of ".$date_select." -".$min." month"));
				$date_list[] = $cur_date;
				$date_select = $cur_date;
				$first = false;
			}
		}
		else{
			$default_margin = $margin;
			$date_list = array();
			$qarr = array("Q1"=>date("Ymd",strtotime($year."-03-".$qdate)),
						  "Q2"=>date("Ymd",strtotime($year."-06-".$qdate)),
						  "Q3"=>date("Ymd",strtotime($year."-09-".$qdate)),
						  "Q4"=>date("Ymd",strtotime($year."-12-".$qdate)));
			$date_select = $qarr[$qdata];
			$date_list[] = date("Ymd",strtotime($date_select));
			$first = true;
			 for($i=0;$i<$default_margin;$i++){
				$min = 12;
				$cur_date = date("Ymd",strtotime($date_select." -".$min." month"));
				$date_list[] = $cur_date;
				$date_select = $cur_date;
				$first = false;
			}
		}
	}
	
	return $date_list;
}

function datelistfix($date_list,$date_input="",$last=true){
	//check status
	$last_status = false;
	if(!empty($date_input)){
		$date_now = date("d",strtotime($date_input));
		$ld_now = date("t",strtotime($date_input));
		if($date_now==$ld_now){
			$last_status = true;
		}
	}
	
	foreach($date_list as $k=>$v){
		if(!empty($cur_date)){
			$last_month = date("m",strtotime($cur_date));
			$cur_month = date("m",strtotime($v));
			if($last_month==$cur_month){
				$date_list[$k+1] = date("Ymt",strtotime($cur_date." -4 days"));
				$cur_date = $date_list[$k+1];
				//echo "sini";
			}
			else{
				$cur_date = $v;
			}
		}
		else{
			$cur_date = $v;
		}
	}
	
	
	//if($last_status==true){
	$total_data = count($date_list);
	$i = 1;
	foreach($date_list as $k=>$v){
		if($last==true or $last_status==true){
			if($i==$total_data){
				$date_list[$k] = date("Ymd",strtotime($v));
			}
			else{
				$date_list[$k] = date("Ymt",strtotime($v));
			}
		}
		else{
			$date_list[$k] = date("Ymd",strtotime($v));
		}
		$i++;
	}
	//}
	return $date_list;
}

function getGroupRole($username=''){
	$ci =& get_instance();
	if(!empty($username)){
		$group_id = get_name("UI_USERS","GROUP_ID","USERNAME",$username);
		$group_role = get_name("UI_GROUPS","LEVEL_ROLEID","GROUP_ID",$group_id);
		
		$group_arr = array("0"=>"CORPORATE",
						   "1"=>"AREA 1",
						   "2"=>"AREA 2",
						   "3"=>"AREA 3",
						   "4"=>"AREA 4");
		return $group_arr[$group_role];
	}
	else{
		return "UNKNOWN";
	}
}

function getPref($param_id) {
    $ci = & get_instance();
    $db2 = $ci->load->database('tria', TRUE);
    $db2->select("PARAM as RESULT")->from("UI_PARAM")->where("PARAM_ID = '" . $param_id . "'");
    $q = $db2->get();
    //echo $ci->db->last_query();
    $rows = $q->result_array();
    if (!empty($rows)) {
        return $rows[0]['RESULT'];
    } else {
        echo $param_id . " not exists";
    }
}

function ldap_check($user,$password){
	$ldap_host = getPref("LDAP_HOST");
	$ldap_dn = "";
	$ldap_user_group = "";
	$ldap_manager_group = "";
	$ldap_usr_dom = getPref("LDAP_DOM");
	$ldap_port = getPref("LDAP_PORT");
	
	$ldap = ldap_connect($ldap_host,$ldap_port);
	ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
	ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);
	
	if($ldap){
		$ldapbind = @ldap_bind($ldap, $user.$ldap_usr_dom, trim($password));
		if($ldapbind) {
			$data["status"] = "true";
			$data["msg"] = "LDAP login : ok";
			write_log($data["msg"],$user);
		} else {
			$data["msg"] = "LDAP Unable to bind to $ldap_host:$ldap_port => invalid credentials : user : $user".$ldap_usr_dom;
			$data["status"] = "false";
			write_log($data["msg"],$user);
		}
	}
	else{
		$data["msg"] = "LDAP Cant connect to $ldap_host:$ldap_port";
		$data["status"] = "false";
		write_log($data["msg"],$user);
	}
	return $data;
}

function weekOfMonth($date) {
    //Get the first day of the month.
    $firstOfMonth = strtotime(date("Y-m-01", $date));
    //Apply above formula.
	//echo intval(date("W", $date))." ".intval(date("W", $firstOfMonth))." ".date("Y-m-d",$firstOfMonth);
    return intval(date("W", $date)) - intval(date("W", $firstOfMonth)) + 1;
}



?>