<?php
$lang['system_program'] = "Program : ";
$lang['system_recent_program'] = "Recent Program";  

$lang['module_dashboard'] = "Dashboard";
$lang['module_dashboard_title'] = "Dashboard";
$lang['module_dashboard_all_program'] = "All Program";

//admin
$lang['module_admin'] = "Admin";

//profile
$lang['module_profile_my_page'] = "User Page";
$lang['module_profile_profile'] = "Profile";
$lang['module_profile_last_login'] = "Last Login";
$lang['module_profile_last_activity'] = "Last Activity";
$lang['module_profile_change_password'] = "Change Password";
$lang['module_profile_save'] = "Save";
$lang['module_old_password_errmsg'] = "Old password is required";
$lang['module_new_password_errmsg'] = "New password is required";
$lang['module_confirm_password_errmsg'] = "Confirm new password is required";
$lang['module_confirm_password_equal_errmsg'] = "Please enter the same password as above";

$lang['module_profile_ph_type_old_password'] = "Old Password";
$lang['module_profile_ph_type_new_password'] = "New Password";
$lang['module_profile_ph_conf_new_password'] = "Confirm New Password";

$lang['module_profile_tooltip_type_old_password'] = "Type Old Password";
$lang['module_profile_tooltip_type_new_password'] = "Type New Password";
$lang['module_profile_tooltip_conf_new_password'] = "Confirm New Password";

//user_management
$lang['module_user_management'] = "User Management";
$lang['module_user_management_title'] = "User Management";
$lang['module_user_management_edit'] = "Edit";
$lang['module_user_management_delete'] = "Delete";
$lang['module_user_management_view_profile'] = "View";
$lang['module_user_management_add_new_row'] = "Add New Row";
$lang['module_user_management_back_to_list'] = "Back to List";
$lang['module_user_management_save'] = "Save";
$lang['module_user_management_user_list'] = "User List";
$lang['module_user_management_user_data'] = "User Data";
$lang['module_user_management_connectivity'] = "Connectivity";

$lang['module_user_management_ph_username'] = "Username";
$lang['module_user_management_ph_departement_name'] = "Departement Name";
$lang['module_user_management_ph_mobile_number'] = "Mobile Number";

$lang['module_user_management_tooltip_username'] = "Define Username for Login Account";
$lang['module_user_management_tooltip_fullname'] = "Define Fullname of this Username";
$lang['module_user_management_tooltip_password'] = "Password must be number-word combination";
$lang['module_user_management_tooltip_departement_name'] = "Type Departement Name";
$lang['module_user_management_tooltip_mobile_number'] = "Type mobile number of this user";
$lang['module_user_management_tooltip_skypeID'] = "Type Skype ID if necessary";
$lang['module_user_management_tooltip_email'] = "Type valid email";
$lang['module_user_management_tooltip_googleID'] = "Type Google ID if necessary";

//log activity
$lang['module_logactivity'] = "Log Activity";
$lang['module_logactivity_title'] = "Log Activity";
$lang['module_logactivity_search'] = "Search";
$lang['module_logactivity_logactivity_list'] = "Log Activity List";

$lang['module_logactivity_ph_startdate'] = "Start Date";
$lang['module_logactivity_ph_enddate'] = "End Date";

//role management
$lang['module_groups'] = "Role Management";
$lang['module_groups_title'] = "Role Management";
$lang['module_groups_add_new_row'] = "Add New Row";
$lang['module_groups_edit'] = "Edit";
$lang['module_groups_privilege_settings'] = "Privilege Settings";
$lang['module_groups_privilege_settings1'] = "- Privilege Settings";
$lang['module_groups_delete'] = "Delete";
$lang['module_groups_group_list'] = "Group List";
$lang['module_groups_group'] = "Group";
$lang['module_groups_back_to_list'] = "Back to List";
$lang['module_groups_save'] = "Save";

$lang['module_groups_ph_group_name'] = "Group Name";

$lang['module_groups_tooltip_group_name'] = "Type Group Name";

//menu management
$lang['module_modulemanager'] = "Menu Management";
$lang['module_modulemanager_title'] = "Menu Management";
$lang['module_modulemanager_add_new_row'] = "Add New Row";
$lang['module_modulemanager_edit'] = "Edit";
$lang['module_modulemanager_delete'] = "Delete";
$lang['module_modulemanager_insert'] = "Insert";
$lang['module_modulemanager_update'] = "Update";
$lang['module_modulemanager_view'] = "View";
$lang['module_modulemanager_module_list'] = "Module List";
$lang['module_modulemanager_back_to_list'] = "Back to List";
$lang['module_modulemanager_save'] = "Save";
$lang['module_modulemanager_enable'] = "Enable";
$lang['module_modulemanager_disable'] = "Disable";
$lang['module_modulemanager_enable_or_disable'] = "Enable or Disable";
$lang['module_modulemanager_access_config'] = "Access Config";
$lang['module_modulemanager_show'] = "Show";
$lang['module_modulemanager_or'] = "or";
$lang['module_modulemanager_hide'] = "Hide";
$lang['module_modulemanager_reference'] = "Reference";
$lang['module_modulemanager_type_modules'] = "Modules";
$lang['module_modulemanager_type_content'] = "Content";


$lang['module_modulemanager_ph_folder_name'] = "Folder Name";
$lang['module_modulemanager_ph_module'] = "Module/menu name";
$lang['module_modulemanager_ph_module_url'] = "Module URL";
$lang['module_modulemanager_ph_module_descrption'] = "Module Description";
$lang['module_modulemanager_ph_sort_index'] = "Sort Index";

$lang['module_modulemanager_tooltip_folder_name'] = "Module var must be same with CI module folder name";
$lang['module_modulemanager_tooltip_module'] = "Module Name will showed at Module List";
$lang['module_modulemanager_tooltip_module_url'] = "Leave blank for default";
$lang['module_modulemanager_tooltip_module_description'] = "Description function of module";
$lang['module_modulemanager_tooltip_sort_index'] = "Sort index position";
$lang['module_modulemanager_tooltip_icon_class'] = "Icon Class Name";

//program management
$lang['module_program'] = "Program Management";
$lang['module_program_edit'] = "Edit";
$lang['module_program_delete'] = "Delete";
$lang['module_program_view_profile'] = "View";
$lang['module_program_add_new_row'] = "Add New Row";
$lang['module_program_program_list'] = "Program List";
$lang['module_program_enable'] = "Enable";
$lang['module_program_disable'] = "Disable";
$lang['module_program_back_to_list'] = "Back to List";
$lang['module_program_save'] = "Save";

$lang['module_program_ph_program_name'] = "Program Name";

$lang['module_program_tooltip_program_name'] = "Type Program Name";

//variable parameter
$lang['module_var_parameter'] = "Variable Parameter";
$lang['module_var_parameter_edit'] = "Edit";
$lang['module_var_parameter_delete'] = "Delete";
$lang['module_var_parameter_view_profile'] = "View";
$lang['module_var_parameter_add_new_row'] = "Add New Row";
$lang['module_var_parameter_var_parameter_list'] = "Variable Parameter List";
$lang['module_var_parameter_back_to_list'] = "Back to List";
$lang['module_var_parameter_save'] = "Save";

$lang['module_var_parameter_ph_description'] = "Description";
$lang['module_var_parameter_ph_tabs'] = "Tabs";
$lang['module_var_parameter_ph_param'] = "Param";

$lang['module_var_parameter_tooltip_param'] = "Type the value of Param Id";
$lang['module_var_parameter_tooltip_param_id'] = "Param ID must be unique";
$lang['module_var_parameter_tooltip_description'] = "Description function of parameter ";
$lang['module_var_parameter_tooltip_tabs'] = "Type grup tabs for parameter list";


//cs_tools
$lang['module_cs_tools'] = "CS Tools";
$lang['module_cs_tools_search'] = "Search";

$lang['module_cs_ro_register'] = "RO Registered Program";
$lang['module_cs_ro_register_search'] = "Search";
$lang['module_cs_ro_register_ph_startdate'] = "Start Date";
$lang['module_cs_ro_register_ph_enddate'] = "End Date";

$lang['module_cs_sp_st_in'] = "SP Stock In";
$lang['module_cs_sp_st_in_search'] = "Search";
$lang['module_cs_sp_st_in_ph_startdate'] = "Start Date";
$lang['module_cs_sp_st_in_ph_enddate'] = "End Date";

$lang['module_cs_reload_trx'] = "Reload TRX";
$lang['module_cs_reload_trx_search'] = "Search";
$lang['module_cs_reload_trx_ph_startdate'] = "Start Date";
$lang['module_cs_reload_trx_ph_enddate'] = "End Date";
$lang['module_cs_reload_trx_invalid_msisdn'] = "Invalid MSISDN Format";

$lang['module_cs_ro_productivity'] = "RO Productivity";
$lang['module_cs_ro_productivity_search'] = "Search";

$lang['module_cs_asli_trx'] = "Asli Transactions";
$lang['module_cs_asli_trx_search'] = "Search";
$lang['module_cs_asli_trx_ph_startdate'] = "Start Date";
$lang['module_cs_asli_trx_ph_enddate'] = "End Date";


$lang['module_cs_pasti_top'] = "Pasti TOP";
$lang['module_cs_pasti_top_search'] = "Search";
$lang['module_cs_pasti_top_invalid_msisdn'] = "Invalid MSISDN Format";


$lang['module_cs_pasti_oke'] = "Pasti OKE";
$lang['module_cs_pasti_oke_search'] = "Search";

$lang['module_cs_dmp_profile'] = "Dompul Profile";
$lang['module_cs_dmp_profile_search'] = "Search";

$lang['module_cs_ro_participant'] = "RO Participant";
$lang['module_cs_ro_participant_search'] = "Search";
$lang['module_cs_ro_participant_ph_startdate'] = "Start Date";
$lang['module_cs_ro_participant_ph_enddate'] = "End Date";

$lang['module_cs_151_trx'] = "151 TRX";
$lang['module_cs_151_trx_search'] = "Search";

//channel_relations
$lang['module_channel_relation'] = "Channel Relation";

$lang['module_news'] = "News Management";
$lang['module_news_title'] = "News Management";
$lang['module_news_add_new_row'] = "Add New Row";
$lang['module_news_edit'] = "Edit";
$lang['module_news_privilege'] = "Privilege";
$lang['module_news_delete'] = "Delete";
$lang['module_news_save'] = "Save";
$lang['module_news_back_to_list'] = "Back to List";
$lang['module_news_news_list'] = "News List";
$lang['module_news_news'] = "News";
$lang['module_news_upload'] = "Upload";
$lang['module_news_upload_image_list'] = "Upload Image List";

$lang['module_news_ph_news_title'] = "News Title";
$lang['module_news_ph_news_preview'] = "News Preview";

//menu help
$lang['module_help'] = "Help"; 

 //module content 
 $lang['module_content'] = "User Help"; 
 

 //module  
 $lang['module_'] = ""; 
 

 //module content_help_user 
 $lang['module_content_help_user'] = "Help User 2"; 
 

 //module coba 
 $lang['module_coba'] = "Admin/coba"; 
 

 //module reporting 
 $lang['module_reporting'] = "Reporting"; 
 

 //module reporting 
 $lang['module_reporting'] = "Reporting"; 
 

 //module reporting 
 $lang['module_reporting'] = "Reporting"; 
 

 //module moduleone 
 $lang['module_moduleone'] = "MO"; 
 
//ticket config
 $lang['module_ticket_config_title'] = "Ticket Configuration";
 $lang['module_ticket_config_add_new_row'] = "Add New Row";
 $lang['module_ticket_config_ph_tc_name'] = "Category Name";
 $lang['module_ticket_config_category'] = "Category";
 $lang['module_ticket_config_tooltip_tc_name'] = "Type Category";
 
 $lang['module_ticket_config_ph_tcc_name'] = "Category Complaint Name";
 $lang['module_ticket_config_complaint_category'] = "Complaint Category";
 $lang['module_ticket_config_tooltip_tcc_name'] = "Type Complaint Category";
 
 