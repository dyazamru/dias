<?php
$lang['system_program'] = "Program : ";
$lang['system_recent_program'] = "Program Terakhir";  

//dashboard module
$lang['module_dashboard'] = "Dashboard";
$lang['module_dashboard_title'] = "Dashboard";
$lang['module_dashboard_all_program'] = "Semua Program";

//admin
$lang['module_admin'] = "Admin";

//profile
$lang['module_profile_my_page'] = "Halaman User";
$lang['module_profile_profile'] = "Profil";
$lang['module_profile_last_login'] = "Login Terakhir";
$lang['module_profile_last_activity'] = "Aktivitas Terakhir";
$lang['module_profile_change_password'] = "Ubah Password";
$lang['module_profile_save'] = "Simpan";
$lang['module_old_password_errmsg'] = "Password lama diperlukan";
$lang['module_new_password_errmsg'] = "Password baru diperlukan";
$lang['module_confirm_password_errmsg'] = "Konfirmasi password baru diperlukan";
$lang['module_confirm_password_equal_errmsg'] = "Konfirmasi password harus sama dengan password baru";

$lang['module_profile_ph_type_old_password'] = "Password Lama";
$lang['module_profile_ph_type_new_password'] = "Password Baru";
$lang['module_profile_ph_conf_new_password'] = "Konfirmasi Password Baru";

$lang['module_profile_tooltip_type_old_password'] = "Isikan Password Lama anda";
$lang['module_profile_tooltip_type_new_password'] = "Isikan Password Baru anda";
$lang['module_profile_tooltip_conf_new_password'] = "Konfirmasi Password Baru anda";

//user managemen
$lang['module_user_management'] = "Manajemen User";
$lang['module_user_management_title'] = "Manajemen User";
$lang['module_user_management_add_new_row'] = "Tambah Baru";
$lang['module_user_management_view_profile'] = "Lihat Profil";
$lang['module_user_management_edit'] = "Ubah";
$lang['module_user_management_delete'] = "Hapus";
$lang['module_user_management_back_to_list'] = "Kembali ke Daftar";
$lang['module_user_management_save'] = "Simpan";
$lang['module_user_management_user_list'] = "Daftar User";
$lang['module_user_management_user_data'] = "Data User";
$lang['module_user_management_connectivity'] = "Konektivitas";

$lang['module_user_management_ph_username'] = "Nama User";
$lang['module_user_management_ph_departement_name'] = "Nama Departemen";
$lang['module_user_management_ph_mobile_number'] = "Nomor Telepon";

$lang['module_user_management_tooltip_username'] = "Nama User untuk Login";
$lang['module_user_management_tooltip_fullname'] = "Nama Lengkap User";
$lang['module_user_management_tooltip_password'] = "Password merupakan kombinasi angka dan huruf";
$lang['module_user_management_tooltip_departement_name'] = "Nama Departemen";
$lang['module_user_management_tooltip_mobile_number'] = "Nomor telepon User";
$lang['module_user_management_tooltip_skypeID'] = "ID Skype bila diperlukan";
$lang['module_user_management_tooltip_email'] = "Isikan email yang valid";
$lang['module_user_management_tooltip_googleID'] = "ID Google bila diperlukan";

//log activity
$lang['module_logactivity'] = "Log Aktivitas";
$lang['module_logactivity_title'] = "Log Aktivitas";
$lang['module_logactivity_search'] = "Cari";
$lang['module_logactivity_logactivity_list'] = "Daftar Log Aktivitas";

$lang['module_logactivity_ph_startdate'] = "Tanggal Mulai";
$lang['module_logactivity_ph_enddate'] = "Tanggal Berakhir";

//groups
$lang['module_groups'] = "Manajemen Grup";
$lang['module_groups_title'] = "Manajemen Grup";
$lang['module_groups_add_new_row'] = "Tambah Baru";
$lang['module_groups_edit'] = "Ubah";
$lang['module_groups_privilege_settings'] = "Atur Hak Akses";
$lang['module_groups_privilege_settings1'] = "- Pengaturan Hak Akses";
$lang['module_groups_delete'] = "Hapus";
$lang['module_groups_group_list'] = "Daftar Grup";
$lang['module_groups_group'] = "Grup";
$lang['module_groups_back_to_list'] = "Kembali ke Daftar";
$lang['module_groups_save'] = "Simpan";

$lang['module_groups_ph_group_name'] = "Nama Grup";

$lang['module_groups_tooltip_group_name'] = "Isikan nama Grup";

//module manager
$lang['module_modulemanager'] = "Manajemen Menu";
$lang['module_modulemanager_title'] = "Manajemen Menu";
$lang['module_modulemanager_add_new_row'] = "Tambah Baru";
$lang['module_modulemanager_edit'] = "Ubah";
$lang['module_modulemanager_delete'] = "Hapus";
$lang['module_modulemanager_insert'] = "Sisipkan";
$lang['module_modulemanager_update'] = "Perbarui";
$lang['module_modulemanager_view'] = "Lihat";
$lang['module_modulemanager_module_list'] = "Daftar Modul";
$lang['module_modulemanager_back_to_list'] = "Kembali ke Daftar";
$lang['module_modulemanager_save'] = "Simpan";
$lang['module_modulemanager_enable'] = "Aktif";
$lang['module_modulemanager_disable'] = "Non Aktif";
$lang['module_modulemanager_enable_or_disable'] = "Aktif atau Non Aktif";
$lang['module_modulemanager_access_config'] = "Konfigurasi Akses";
$lang['module_modulemanager_show'] = "Tampilkan";
$lang['module_modulemanager_or'] = "atau";
$lang['module_modulemanager_hide'] = "Sembunyikan";
$lang['module_modulemanager_reference'] = "Referensi";
$lang['module_modulemanager_type_modules'] = "Modul";
$lang['module_modulemanager_type_content'] = "Konten";


$lang['module_modulemanager_ph_folder_name'] = "Nama Folder";
$lang['module_modulemanager_ph_module'] = "Modul/nama menu";
$lang['module_modulemanager_ph_module_url'] = "URL Modul";
$lang['module_modulemanager_ph_module_descrption'] = "Deskripsi Modul";
$lang['module_modulemanager_ph_sort_index'] = "Urutkan";

$lang['module_modulemanager_tooltip_folder_name'] = "Variabel Modul harus sama dengan Nama Folder CI Module";
$lang['module_modulemanager_tooltip_module'] = "Nama Modul akan muncul di Daftar Modul";
$lang['module_modulemanager_tooltip_module_url'] = "Kosongkan untuk default";
$lang['module_modulemanager_tooltip_module_description'] = "Deskripsi fungsi dari modul";
$lang['module_modulemanager_tooltip_sort_index'] = "Urutkan posisi index";
$lang['module_modulemanager_tooltip_icon_class'] = "Nama Icon Class";

//program
$lang['module_program'] = "Manajemen Program";
$lang['module_program_title'] = "Manajemen Program";
$lang['module_program_add_new_row'] = "Tambah Baru";
$lang['module_program_edit'] = "Ubah";
$lang['module_program_delete'] = "Hapus";
$lang['module_program_program_list'] = "Daftar Program";
$lang['module_program_back_to_list'] = "Kembali ke Daftar";
$lang['module_program_save'] = "Simpan";
$lang['module_program_enable'] = "Aktif";
$lang['module_program_disable'] = "Non Aktif";
$lang['module_program_enable_or_disable'] = "Aktif atau Non Aktif";

$lang['module_program_ph_program_name'] = "Nama Program";

$lang['module_program_tooltip_program_name'] = "Tipe Nama Program";


//var_parameter
$lang['module_var_parameter'] = "Variabel Parameter";
$lang['module_var_parameter_title'] = "Variabel Parameter";
$lang['module_var_parameter_add_new_row'] = "Tambah Baru";
$lang['module_var_parameter_edit'] = "Ubah";
$lang['module_var_parameter_delete'] = "Hapus";
$lang['module_var_parameter_add'] = "Tambah";
$lang['module_var_parameter_var_parameter_list'] = "Daftar Variabel Parameter";
$lang['module_var_parameter_back_to_list'] = "Kembali ke Daftar";
$lang['module_var_parameter_save'] = "Simpan";

$lang['module_var_parameter_ph_description'] = "Deskripsi";
$lang['module_var_parameter_ph_tabs'] = "Tab";
$lang['module_var_parameter_ph_param'] = "Param";

$lang['module_var_parameter_tooltip_param'] = "Nilai parameter";
$lang['module_var_parameter_tooltip_param_id'] = "Param ID Harus Unik";
$lang['module_var_parameter_tooltip_description'] = "Deskripsi fungsi dari parameter ";
$lang['module_var_parameter_tooltip_tabs'] = "Isi grup tab untuk daftar parameter";

//cs tools
$lang['module_cs_tools'] = "CS Tools";

//cs_ro_register
$lang['module_cs_ro_register'] = "RO Registered Program";
$lang['module_cs_ro_register_search'] = "Cari";

$lang['module_cs_ro_register_ph_startdate'] = "Tanggal Mulai";
$lang['module_cs_ro_register_ph_enddate'] = "Tanggal Berakhir";

//cs_sp_st_in
$lang['module_cs_sp_st_in'] = "SP Stock In";
$lang['module_cs_sp_st_in_search'] = "Cari";

$lang['module_cs_sp_st_in_ph_startdate'] = "Tanggal Mulai";
$lang['module_cs_sp_st_in_ph_enddate'] = "Tanggal Berakhir";

//cs_reload_trx
$lang['module_cs_reload_trx'] = "Reload TRX";
$lang['module_cs_reload_trx_search'] = "Cari";

$lang['module_cs_reload_trx_ph_startdate'] = "Tanggal Mulai";
$lang['module_cs_reload_trx_ph_enddate'] = "Tanggal Berakhir";

//cs_ro_productivity
$lang['module_cs_ro_productivity'] = "RO Productivity";
$lang['module_cs_ro_productivity_search'] = "Cari";

//cs_asli_trx
$lang['module_cs_asli_trx'] = "Asli Transactions";
$lang['module_cs_asli_trx_search'] = "Cari";

$lang['module_cs_asli_trx_msisdn'] = "Format MSISDN salah";
$lang['module_cs_asli_trx_ph_startdate'] = "Tanggal Mulai";
$lang['module_cs_asli_trx_ph_enddate'] = "Tanggal Berakhir";

//cs_pasti_top
$lang['module_cs_pasti_top'] = "Pasti Top";
$lang['module_cs_pasti_top_search'] = "Cari";

$lang['module_cs_pasti_top_ph_startdate'] = "Tanggal Mulai";
$lang['module_cs_pasti_top_ph_enddate'] = "Tanggal Berakhir";

//cs_pasti_oke
$lang['module_cs_pasti_oke'] = "Pasti Oke";
$lang['module_cs_pasti_oke_search'] = "Cari";

$lang['module_cs_pasti_oke_msisdn'] = "Format MSISDN salah";
$lang['module_cs_pasti_oke_ph_startdate'] = "Tanggal Mulai";
$lang['module_cs_pasti_oke_ph_enddate'] = "Tanggal Berakhir";

//cs_dmp_profile
$lang['module_cs_dmp_profile'] = "Dompul Profiles";
$lang['module_cs_dmp_profile_search'] = "Cari";

//cs_ro_participant
$lang['module_cs_ro_participant'] = "RO Participant";
$lang['module_cs_ro_participant_search'] = "Cari";

$lang['module_cs_ro_participant_ph_startdate'] = "Tanggal Mulai";
$lang['module_cs_ro_participant_ph_enddate'] = "Tanggal Berakhir";

//cs_151_trx
$lang['module_cs_151_trx'] = "151 TRX";
$lang['module_cs_151_trx_search'] = "Cari";

$lang['module_cs_151_trx_startdate'] = "Tanggal Mulai";
$lang['module_cs_151_trx_ph_enddate'] = "Tanggal Berakhir";

//channel relation
$lang['module_channel_relation'] = "Channel Relation";

//news management
$lang['module_news'] = "Manajemen Berita";
$lang['module_news_title'] = "Manajemen Berita";
$lang['module_news_add_new_row'] = "Tambah Baru";
$lang['module_news_edit'] = "Ubah";
$lang['module_news_privilege'] = "Hak Akses";
$lang['module_news_delete'] = "Hapus";
$lang['module_news_save'] = "Simpan";
$lang['module_news_back_to_list'] = "Kembali ke Daftar";
$lang['module_news_news_list'] = "Daftar Berita";
$lang['module_news_news'] = "Berita";
$lang['module_news_upload'] = "Unggah";
$lang['module_news_upload_image_list'] = "Daftar Unggah Gambar";

$lang['module_news_ph_news_title'] = "Judul Berita";
$lang['module_news_ph_news_preview'] = "Ulasan Berita";

//menu help
$lang['module_help'] = "Bantuan"; 

 //module content 
 $lang['module_content'] = "User Help"; 
 

 //module  
 $lang['module_'] = ""; 
 

 //module content_help_user 
 $lang['module_content_help_user'] = "Help User 2"; 
 

 //module coba 
 $lang['module_coba'] = "Admin/coba"; 
 

 //module reporting 
 $lang['module_reporting'] = "Reporting"; 
 

 //module reporting 
 $lang['module_reporting'] = "Reporting"; 
 

 //module reporting 
 $lang['module_reporting'] = "Reporting"; 
 

 //module moduleone 
 $lang['module_moduleone'] = "MO"; 

 //TICKET CONFIG
 $lang['module_ticket_config_title'] = "Ticket Configuration";
 $lang['module_ticket_config_add_new_row'] = "Tambah Baru";
 $lang['module_ticket_config_ph_tc_name'] = "Nama Category";
 $lang['module_ticket_config_category'] = "Category";
 $lang['module_ticket_config_tooltip_tc_name'] = "Isikan Category";
 
 $lang['module_ticket_config_ph_tcc_name'] = "Category Complaint Name";
 $lang['module_ticket_config_complaint_category'] = "Complaint Category";
 $lang['module_ticket_config_tooltip_tcc_name'] = "Isikan Complaint Category";
 