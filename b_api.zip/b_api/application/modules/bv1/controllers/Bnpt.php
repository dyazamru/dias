<?php defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH.'/libraries/REST_Controller.php';

class Bnpt extends REST_Controller
{
   function __construct(){
	parent::__construct();
	//$this->load->model('rest_admin_model');	
   }

   function test_user_post(){
	$val = $this->input->post('username');
	$data['user'] = 'Admin';
	$data['username'] = $val;
	$this->response($data,200);
   }

//jdih
   function get_jdihDocument_post(){
	$this->db->select('*')->from('document');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }

   function get_jdihDownload_post(){
	$this->db->select('*')->from('download_counter');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }

   function get_jdihItem_post(){
	$this->db->select('*')->from('item');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
//sikepo
   function get_sikepoCuti_post(){
	$this->db->select('*')->from('tb_pengajuan_cuti');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }

   function get_sikepoSpd_post(){
	$this->db->select('*')->from('tb_spd');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }

   function get_sikepoDataPribadi_post(){
	$this->db->select('*')->from('tb_data_pribadi');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }

   function get_sikepoJamAbsen_post(){
	$this->db->select('*')->from('jadwal_jam_absen');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }

   function get_sikepoPegawai_post(){
	$this->db->select('*')->from('tb_pegawai');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }

//simaksi
   function get_detailPengajuan_post(){
	$this->db->select('*')->from('tmp_uraian_pengajuan');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_simUraianRab_post(){
	$this->db->select('*')->from('uraian_rab');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }

//simolek
   function get_simolImplementasi_post(){
	$this->db->select('*')->from('implementasi_satker');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_simolKomponen_post(){
	$this->db->select('*')->from('realisasi_komponen_satker');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_simolRpok_post(){
	$this->db->select('*')->from('rpok');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_simolCapaian_post(){
	$this->db->select('*')->from('t_ikk_capaian');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
//simonsikat
   function get_simonProp_post(){
	$this->db->select('*')->from('m_prop');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_simonRefInstansi_post(){
	$this->db->select('*')->from('ref_instansi');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_simonLokasi_post(){
	$this->db->select('*')->from('tbl_lokasi_kegiatan');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_simonTarget_post(){
	$this->db->select('*')->from('tbl_target');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_simonUpdate_post(){
	$this->db->select('*')->from('tbl_update_realiasi');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }

//sip
   function get_sipUnitKerja_post(){
	$this->db->select('*')->from('simpeg_unit_kerja_pegawai');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_sipDiklat_post(){
	$this->db->select('*')->from('tb_diklat');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_sipJabatan_post(){
	$this->db->select('*')->from('tb_jabatan');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_sipAlamat_post(){
	$this->db->select('*')->from('tb_alamat');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_sipKeluarga_post(){
	$this->db->select('*')->from('tb_keluarga');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_sipPangkat_post(){
	$this->db->select('*')->from('tb_pangkat');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_sipPendidikan_post(){
	$this->db->select('*')->from('tb_pendidikan');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_sipPendMiliter_post(){
	$this->db->select('*')->from('tb_pendidikan_militer');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
//siperdis
   function get_siperdisKwitansi_post(){
	$this->db->select('*')->from('tb_kwitansi');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_siperdisSpd_post(){
	$this->db->select('*')->from('tb_spd');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_siperdisPegawai_post(){
	$this->db->select('*')->from('tb_pegawai');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_siperdisTujuan_post(){
	$this->db->select('*')->from('tb_tujuan');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
//sipuja
   function get_sipujaJabatan_post(){
	$this->db->select('*')->from('app_kelas_jabatan');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   function get_sipujaSpd_post(){
	$this->db->select('*')->from('tb_spd');
	$q = $this->db->get();
	$res = $q->result_array();
		
	$this->response($res,200);
   }
   
   
}
?>